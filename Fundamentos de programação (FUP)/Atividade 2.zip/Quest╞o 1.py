x = int(input("Digite um número: "))
 
centena = x // 100
unidade = x % 10 
dezena = (x%100)// 10 
print('\n')
print('Algarismo das centenas: ' + str(centena))
print('Algarismo das dezenas: ' + str(dezena))
print('Algarismo das unidades: ' + str(unidade))

