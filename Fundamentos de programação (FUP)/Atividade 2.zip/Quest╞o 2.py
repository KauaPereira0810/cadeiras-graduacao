x = input('Digite uma palavra: ').upper()

if (len(x) == 5) and (x[0] == x[4] and x[1] ==  x[3]):
    print('Sua palavra é um palíndromo')
else:
    print('Erro. Sua palavra não é um palíndromo')