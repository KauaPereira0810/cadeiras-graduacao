x = int(input('Digite um número: '))

if x % 2 == 0:
    print('O número {} é divisível por 2'.format(x))
else:
    print('O número {} não é divisível por 2'.format(x))
if x % 5 == 0:
    print('O número {} é divisível por 5'.format(x))
else:
    print('O número {} não é divisível por 5'.format(x))
if x % 7 == 0:
    print('O número {} é divisível por 7'.format(x))
else:
    print('O número {} não é divisível por 7'.format(x)) 
if x % 10 == 0:
    print('O número {} é divisível por 10'.format(x))
else:
    print('O número {} não é divisível por 10'.format(x))
if x % 35 == 0:
    print('O número {} é divisível por 35'.format(x))
else:
    print('O número {} não é divisível por 35'.format(x))
      