def lst0(list):
    lst0 = []
    for x in lst1:
        lst0.append(0)
    return(lst0)
        
lst1 = []
 
n = int(input("Quantos elementos terá sua lista? : "))
 
for i in range(0, n):
    a = int(input('Insira um elemento: ')) 
    lst1.append(a)
print(f'A lista modificada é: {lst0(list)}')