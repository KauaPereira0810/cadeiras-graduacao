lista = []
n = int(input("Quantos elementos terá sua lista? : "))
 
for i in range(0, n):
    a = int(input("Insira um elemento: ")) 
    lista.append(a) 

def max_lista(lista):
    maior = lista[0]
    for x in lista:
        if (x > maior):
            maior = x
    print('='*30)
    print(f'O maior valor da lista é: {maior}')

max_lista(lista)