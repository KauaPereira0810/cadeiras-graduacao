def concatenar(lst1):
    y =''
    for x in lst1:
        x = ''.join(z for z in x if z.isalnum())
        y = y + x
    print(y)
    
lst1 = []
 
n = int(input("Quantas strings terá sua lista? : "))

for i in range(0, n):
    a = str(input('Insira uma string: ')) 
    lst1.append(a)
    
concatenar(lst1)