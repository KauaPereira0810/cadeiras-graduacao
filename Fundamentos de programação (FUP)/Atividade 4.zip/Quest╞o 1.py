def encMaior(L):
    maior = L[0]
    for elemento in L:
        if elemento[0] > maior[0]:
            maior = elemento
    return maior
 

L = [(7,7),(10,20,30),(0,0),(2,8)]
R = [(99,22),(19,10,10), (90,), (1,2,3)]

print(encMaior(L))
print(encMaior(R))