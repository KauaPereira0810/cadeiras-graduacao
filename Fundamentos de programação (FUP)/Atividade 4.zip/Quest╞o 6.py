def max_lists(x,y):
    max_list=[]
    a = 0
    for w in x:
        if x[a]>y[a]:
            max_list.append(x[a])
            a = a+1
        else:
            max_list.append(y[a])
            a = a+1
    return(max_list)
x = []
 
n = int(input("Quantos elementos terá sua 1ª lista? : "))
 
for i in range(0, n):
    b = int(input('Insira um número da 1ª lista: ')) 
    x.append(b) 

print(x)
print('=' * 30)
y = []
 
c = int(input("Quantos elementos terá sua 2ª lista? : "))
 
for c in range(0, c):
    d = int(input('Insira um número da 2ª lista: ')) 
    y.append(d) 

print(y)
print('=' * 30)
if len(y) != len(x):
    print('Erro. Suas listas não tem o mesmo comprimento')
else:
    print(f'A lista com os máximos é: {max_lists(x,y)}')