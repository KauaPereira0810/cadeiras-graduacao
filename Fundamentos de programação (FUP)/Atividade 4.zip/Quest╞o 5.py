def valores(lst1):
    x = lst1[0]
    y = lst1[0]
    for i in lst1:
        if x < i:
            x=i
    for c in lst1:
        if y>c:
            y=c
    return(x,y)
            
        
lst1 = []
 
n = int(input("Quantos elementos terá sua lista? : "))
 
for i in range(0, n):
    a = int(input('Insira um número: ')) 
    lst1.append(a) 
     
print(f'O maior e o menor valor são: {valores(lst1)}')
